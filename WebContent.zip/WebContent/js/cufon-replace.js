Cufon.replace('#menu a, .tabs a, h2, .button, h3', { fontFamily: 'Myriad Pro', hover:true });

