/**
 * 
 */
$(function() {
	transformecurseur('#menu_prix', 'pointer');
	transformecurseur('#menu_horaire', 'pointer');
	transformecurseur('#menu_proximite', 'pointer');
	transformecurseur('#menu_standing', 'pointer');
});